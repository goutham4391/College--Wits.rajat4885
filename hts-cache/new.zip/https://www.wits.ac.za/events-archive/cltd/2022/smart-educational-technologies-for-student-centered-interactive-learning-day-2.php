
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="author" content="The University of the Witwatersrand, Johannesburg">
  <meta name="generator" content="TERMINALFOUR">

  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-10871141-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-10871141-1');
</script>

  <script type="text/javascript">
            var vsid = "sa51850";
            (function () {
                var vsjs = document.createElement('script');
                vsjs.type = 'text/javascript';
                vsjs.async = true;
                vsjs.setAttribute('defer', 'defer');
                vsjs.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'www.virtualspirits.com/vsa/chat-' + vsid + 
                '.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(vsjs, s);
            })();
        </script>
  <meta name="description" content="">
  
  
  <title>2022 - Wits University</title>
  
  <link rel="shortcut icon" href="/media/wits-university-style-assets/images/favicon.ico" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/style-local.css" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/slick.css" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/style-updates.css" />
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400italic,400,700,600" type="text/css">

  <style>
    td.hasEvents:hover {
    	background-color: #007cc2 !important;
    	text-decoration: underline !important;
    }
  </style>

 	<!-- T4 updated style -->
  <link rel="stylesheet" type="text/css" media="" href="/media/wits-university-style-assets/css/style-updates-renamed.css" />
  <!-- Redesign css -->
  <link rel="stylesheet" type="text/css" media="" href="/media/wits-university-style-assets/css/redesign.css" />

  <script src="/media/wits-university-style-assets/javascript/modernizr.js"></script>
</head>
<body class="gen-content events">
  <div class="emergencynotice" aria-live="assertive"></div>
  <!--** End .outer-wrap contains everything **-->
  <div class="off-canvas-wrap" data-offcanvas>
    <!--** Main body .inner-wrap wraps around all content **-->
    <main class="inner-wrap">
			<!--** Desktop header **-->
      <header aria-hidden="true" class="page-head-desktop">
        <section class="content-row">
          <!--** Logo **-->
          <div class="logo-desktop">
              <a href="/" title="University of the Witwatersrand"><img src="/media/wits-university-style-assets/images/Wits_Centenary_Logo_Large.svg" alt="The University of the Witwatersrand Logo" title="The University of the Witwatersrand Logo" class="" style="   " ></a>
          </div>
          <!--** End Logo **-->
          <!--** Meta-nav and Search **-->
          <div class="meta-nav-and-search ">
            <!--** Meta-nav **-->
            <div class="meta-nav">
              <ul class="inline-list">
              <li><a href="/about-wits/">About</a></li><li><a href="/staff/">Staff</a></li><li><a href="/alumni/">Alumni</a></li><li><a href="/givingtowits/">Give</a></li><li><a href="/library/">Library</a></li><li><a href="/news/">News and Events</a></li><li><a href="http://wits100.wits.ac.za" target="_blank">Wits100</a></li>
              </ul>
            </div>
            <!--** End Meta-nav **-->
            <!--** Desktop main nav **-->
            <div class="navigation-search">
              <a href="/">
              <button class="homepage-link button" title="Link to homepage"
                ><i class="fa fa-home"></i><span class="sr-only">Homepage</span>
              </button>
              </a>
              <nav class="content-row main-nav">
                <div class="content-block">
                  <ul class="inline-list">
                    <li><a href="/study-at-wits/">Study at Wits</a></li><li><a href="/students/">Students</a></li><li><a href="/faculties-and-schools/">Faculties and Schools</a></li><li><a href="/teaching-and-learning/">Teaching and Learning</a></li><li><a href="/research/">Research</a></li><li><a href="/news/">News</a></li>
                  </ul>    
                </div>
              </nav>
              <button class="search-display button" title="Search bar revelar"
                ><i class="fa fa-search"></i><span class="sr-only">Search</span>
              </button>
            </div>
            
            <!--** Search **-->
            <div class="search search-hidden">
              <form id="site-search" action="/search-results/">
                                    <label class="site-search-label at-hidden" for="site-search-text-d">Search the site</label>
                                    <div class="content-row search-row">
                                        <div class="site-search-text content-block">
                                            <input type="text" name="q" id="site-search-text-d" placeholder="Search">
                                        </div>
                                        <div class="search-now content-block">
                                            <span class="postfix">
                                                <button type="submit" class="search-now button" title="Search now">
                                                    <i class="fa fa-search"></i>
                                                    <span>Search</span>
                                                </button>                                                    
                                            </span>
                                        </div>
                                    </div>
                                </form>
            </div>
            <!--** End search **-->
          </div>
          <!--** End Meta-nav and Search **-->
        </section>       
      </header>
      <!--** End desktop header **-->
      <!--** Mobile Header **-->
      <header class="mobile-header">
        <!--** Mobile Top panel **-->
        <nav class="tab-bar">
            <section class="left-small">
              <a class="left-off-canvas-toggle menu-icon" href="#off-canvas">
                <span></span>
                Menu
              </a>
            </section>
            <section class="right-small">
              <a class="search-toggle" href="#">Search <i class="fa fa-search"></i></a>
            </section>
        </nav>
        <!--** Mobile Top panel **-->
        <!--** Mob site search **-->
        <section class="mobile-site-search content-row">
          <div class="content-block">
            <form id="site-search" action="/search-results/">
                                    <label class="site-search-label at-hidden" for="site-search-text-d">Search the site</label>
                                    <div class="content-row search-row">
                                        <div class="site-search-text content-block">
                                            <input type="text" name="q" id="site-search-text-d" placeholder="Search">
                                        </div>
                                        <div class="search-now content-block">
                                            <span class="postfix">
                                                <button type="submit" class="search-now button" title="Search now">
                                                    <i class="fa fa-search"></i>
                                                    <span>Search</span>
                                                </button>                                                    
                                            </span>
                                        </div>
                                    </div>
                                </form>
          </div>
        </section>
        <!--** End mob site search **-->           
        <!--** Mobile logo **-->
        <section class="logos logo-mobile">
          <div class="wits-logo logo"><a href="/" title="University of the Witwatersrand"><img src="/media/wits-university-style-assets/images/Wits_Centenary_Logo_Large.svg" alt="The University of the Witwatersrand Logo" title="The University of the Witwatersrand Logo" class="" style="   " ></a></div>
        </section>
        <!--** End logo mobile **-->

        <!--** Off canvas menu **-->
        <aside id="off-canvas" class="left-off-canvas-menu">
          <p class="at-hidden"><a href="#start-content">Skip navigation and go to page content</a></p>
          <nav>
            <!-- Main nav -->
            <ul class="off-canvas-list">
              <li><label>Sections</label></li>
              <li><a href="/study-at-wits/">Study at Wits</a></li><li><a href="/students/">Students</a></li><li><a href="/faculties-and-schools/">Faculties and Schools</a></li><li><a href="/teaching-and-learning/">Teaching and Learning</a></li><li><a href="/research/">Research</a></li><li><a href="/news/">News</a></li>
            </ul>
            <!-- End main nav -->
            <!-- Meta nav -->
             <ul class="off-canvas-meta-nav">
              <li><a href="/about-wits/">About</a></li><li><a href="/staff/">Staff</a></li><li><a href="/alumni/">Alumni</a></li><li><a href="/givingtowits/">Give</a></li><li><a href="/library/">Library</a></li><li><a href="/news/">News and Events</a></li><li><a href="http://wits100.wits.ac.za" target="_blank">Wits100</a></li>
            </ul>
            <!-- End Meta nav -->
          </nav>
        </aside>
        <!--** End off canvas menu **-->
      </header>
      <!--** End Mobile header **-->
      <!--** Ribbon message for users on IE<10 **-->
      <div style="display: none;" class="content-row ie-ribbon"></div> 
      <!--** Start content **-->
      <a id="start-content" name="start-content" class="at-hidden">Start main page content</a>
      <section class="content-row no-padding-bottom">
        <nav class="content-block">
          <ul class="breadcrumbs"><li><a href="/">Home</a><i class="fa fa-angle-right"></i></li><li><a href="/events-archive/">Events Archive</a><i class="fa fa-angle-right"></i></li><li><a href="/events-archive/cltd/">CLTD</a><i class="fa fa-angle-right"></i></li><li>2022</li></ul>
        </nav>
      </section>

      <section class="gen-main-content-row content-row">
        <section class="gen-main-body content-block" style="padding-left: 2rem;">
          <h1>Events</h1>
<div class="grid-container">
  <div class="event-fulltext" data-contentid="2896286">
<h1>Smart Educational Technologies for Student-centered (Inter)active Learning (Day 2)</h1>
<table class="event-details">
  <tbody>
    <tr>
      <td>When:</td>
      <td>        
        <!--You need to load the T4EventsCalendar Class-->    Wednesday, 09 November 2022

                 
</td>
    </tr>  
    <tr>
      <td>Where:</td>
      <td><br>Gatehouse Building (GH403), East Campus</td>
    </tr>  
    <tr>
      <td>Start time:</td><td>10:00</td>
    </tr> 
    <tr>
      <td>Enquiries:</td><td><p><strong><a href="mailto:mei.luo@wits.ac.za">mei.luo@wits.ac.za</a>&nbsp;</strong></p>
<p><strong>To attend this training, please book&nbsp;<a href="https://docs.google.com/spreadsheets/d/1M3-ZjcVmkTBv1pD_kqs17U_W80G5mxJaMDjM858fVaA/edit#gid=0">here</a></strong></p></td>
    </tr> 
    
    
  </tbody>
</table>


<p class="intro"></p>
<p>The evolution of technology has changed the landscape of education. The use of smart technologies that could enable agentic, interactive learning and teaching have become widespread. Smart learning environments have been gaining traction in education since it allows the fostering of collaborative learning opportunities where educational technologies are used meaningfully. Our two-day training webinar and face-to-face workshop consist of the following:</p>
<h4><span>Day 1: Online (9:00 &ndash; 10:30)</span></h4>
<p>This session will introduce participants to the Smart Classroom teaching and learning technologies and suggest ways to use these technologies to create an (inter)active student-centered learning experience.</p>
<h4><span>Day 2: Face-to-face, onsite (10:00 &ndash; 12:30 in Gatehouse building GH403, East Campus)</span></h4>
<p><strong><span>&nbsp;</span></strong>This face-to-face workshop occurs the day after the webinar and will demonstrate how smart technologies may be applied in real-life teaching and learning situations and will offer participants an opportunity to test out various teaching and learning scenarios.</p>
<p>Please note that due to COVID-19 regulations we will only be accepting 12 participants per training session. Bookings need to be made <u>at least 48 hours prior to</u> <u>the training session</u> and participants should arrive at the onsite workshops at least<u> 15</u> <u>minutes before the session begins.</u></p>
<p>To support you further, we have also developed a self-directed course that provides suggestions of various approaches that one could use in the Smart Classroom. To learn more about this course, click <strong><a href="https://ulwazi.wits.ac.za/enroll/JFDR8E">here</a></strong>.</p>
<p class="p1"><strong>Date: 9 November 2022 (Day 2: Onsite - Face to Face)</strong></p>
<p><strong>Time: 10:00 - 12:30</strong></p>
<p><strong>Venue: Gatehouse (GH403) Face-to-face session&nbsp;</strong></p>
  
  <a class="ical-btn" href="/events-archive/cltd/2022/event-2896286.ics"><img class="ical-img" src="/media/wits-university/campus-life/images/Calendar-Date-04.png" alt="calendar icon" >Add event to calendar</a>
  <br>
</div>
</div>
<!--<a href="/events-archive/cltd/2022/smart-educational-technologies-for-student-centered-interactive-learning-day-2-15.php">Smart Educational Technologies for Student-centered (Inter)active Learning (Day 2)</a>-->
              





<!--
<div class="grid-container">
  <div class="event-fulltext" data-contentid="2896286">
<h1>Smart Educational Technologies for Student-centered (Inter)active Learning (Day 2)</h1>
<table class="event-details">
  <tbody>
    <tr>
      <td>When:</td>
      <td>Wednesday, 09 November 2022</td>
    </tr>  
    <tr>
      <td>Where:</td>
      <td><br>Gatehouse Building (GH403), East Campus</td>
    </tr>  
    <tr>
      <td>Start time:</td><td>10:00</td>
    </tr> 
    <tr>
      <td>Enquiries:</td><td><p><strong><a href="mailto:mei.luo@wits.ac.za">mei.luo@wits.ac.za</a>&nbsp;</strong></p>
<p><strong>To attend this training, please book&nbsp;<a href="https://docs.google.com/spreadsheets/d/1M3-ZjcVmkTBv1pD_kqs17U_W80G5mxJaMDjM858fVaA/edit#gid=0">here</a></strong></p></td>
    </tr> 
    
    
  </tbody>
</table>


<p class="intro"></p>
<p>The evolution of technology has changed the landscape of education. The use of smart technologies that could enable agentic, interactive learning and teaching have become widespread. Smart learning environments have been gaining traction in education since it allows the fostering of collaborative learning opportunities where educational technologies are used meaningfully. Our two-day training webinar and face-to-face workshop consist of the following:</p>
<h4><span>Day 1: Online (9:00 &ndash; 10:30)</span></h4>
<p>This session will introduce participants to the Smart Classroom teaching and learning technologies and suggest ways to use these technologies to create an (inter)active student-centered learning experience.</p>
<h4><span>Day 2: Face-to-face, onsite (10:00 &ndash; 12:30 in Gatehouse building GH403, East Campus)</span></h4>
<p><strong><span>&nbsp;</span></strong>This face-to-face workshop occurs the day after the webinar and will demonstrate how smart technologies may be applied in real-life teaching and learning situations and will offer participants an opportunity to test out various teaching and learning scenarios.</p>
<p>Please note that due to COVID-19 regulations we will only be accepting 12 participants per training session. Bookings need to be made <u>at least 48 hours prior to</u> <u>the training session</u> and participants should arrive at the onsite workshops at least<u> 15</u> <u>minutes before the session begins.</u></p>
<p>To support you further, we have also developed a self-directed course that provides suggestions of various approaches that one could use in the Smart Classroom. To learn more about this course, click <strong><a href="https://ulwazi.wits.ac.za/enroll/JFDR8E">here</a></strong>.</p>
<p class="p1"><strong>Date: 9 November 2022 (Day 2: Onsite - Face to Face)</strong></p>
<p><strong>Time: 10:00 - 12:30</strong></p>
<p><strong>Venue: Gatehouse (GH403) Face-to-face session&nbsp;</strong></p>
  
  <a class="ical-btn" href="/events-archive/cltd/2022/event-2896286.ics"><img class="ical-img" src="/media/wits-university/campus-life/images/Calendar-Date-04.png" alt="calendar icon" >Add event to calendar</a>
  <br>
</div>
</div>
<!--<a href="/events-archive/cltd/2022/smart-educational-technologies-for-student-centered-interactive-learning-day-2-15.php">Smart Educational Technologies for Student-centered (Inter)active Learning (Day 2)</a>-->  </section>

  <aside class="gen-content-lh-sidebar content-block">
    <div class="content-row">
		  <!-- Events Calendar v2 by TERMINALFOUR -->
<!-- T4\Calendar :: Version: 2.4 -->
<div class="pcb-mini-cal ajax-load-area content-block" id="calendar_box" data-ajaxloadalso='["calendar_page","calendar_events", "view_period_switchers", "view-switchers","hidden_form","jumpto_hidden_form","calendar_events","past_events","searchoptions-generic","searchoptions-categories"]'>
    <table class="cal-table">
        <thead>
        <tr class="calendar-box-header">
            
            <th  id="prev_month">
                                <a href="?month=10&year=2022&search=month&event_id=2896286" class="ajax-load-link" ><span class="fa fa-chevron-left"></span><span class="prev-next-link"></span></a>
                            </th>
                        <th colspan="5" id="current_month"><a href="/display/events/?month=11&year=2022&search=month" class="ajax-load-link">November 2022</a></th>
            
            <th  id="next_month">
                                <a href="?month=12&year=2022&search=month&event_id=2896286" class="ajax-load-link" ><span class="fa fa-chevron-right"></span><span class="prev-next-link"></span></a>
                            </th>
        </tr>
                <tr class="calendar-dayhead">
                                                            <th id="heading-0" headers="current_month"><span>Mo</span></th>
                                                            <th id="heading-1" headers="current_month"><span>Tu</span></th>
                                                            <th id="heading-2" headers="current_month"><span>We</span></th>
                                                            <th id="heading-3" headers="current_month"><span>Th</span></th>
                                                            <th id="heading-4" headers="current_month"><span>Fr</span></th>
                                                            <th id="heading-5" headers="current_month"><span>Sa</span></th>
                                                            <th id="heading-6" headers="current_month"><span>Su</span></th>
                    </tr>

        </thead>

        <tbody>
        
                                <tr class="calendar-dayrow">
                                                                                                                       <td class="fillday outperiodday  hasEvents NotInFilter" headers="heading-0" id="day2022_10_31" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=31&month=10&year=2022&search=day" class="ajax-load-link">31</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-1" id="day2022_11_01" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=01&month=11&year=2022&search=day" class="ajax-load-link">01</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-2" id="day2022_11_02" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=02&month=11&year=2022&search=day" class="ajax-load-link">02</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-3" id="day2022_11_03" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=03&month=11&year=2022&search=day" class="ajax-load-link">03</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-4" id="day2022_11_04">
                            <span>04</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-5" id="day2022_11_05">
                            <span>05</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-6" id="day2022_11_06">
                            <span>06</span>
                        </td>
                                                </tr>
                                <tr class="calendar-dayrow">
                                                                                                                       <td class="thismonth viewrange periodday " headers="heading-0" id="day2022_11_07">
                            <span>07</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday  hasEvents NotInFilter" headers="heading-1" id="day2022_11_08" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=08&month=11&year=2022&search=day" class="ajax-load-link">08</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday  hasEvents NotInFilter" headers="heading-2" id="day2022_11_09" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=09&month=11&year=2022&search=day" class="ajax-load-link">09</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday  hasEvents NotInFilter" headers="heading-3" id="day2022_11_10" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=10&month=11&year=2022&search=day" class="ajax-load-link">10</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday " headers="heading-4" id="day2022_11_11">
                            <span>11</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday " headers="heading-5" id="day2022_11_12">
                            <span>12</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange periodday today hasEvents NotInFilter" headers="heading-6" id="day2022_11_13" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=13&month=11&year=2022&search=day" class="ajax-load-link">13</a>
                        </td>
                                                </tr>
                                <tr class="calendar-dayrow">
                                                                                                                       <td class="thismonth viewrange outperiodday " headers="heading-0" id="day2022_11_14">
                            <span>14</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-1" id="day2022_11_15" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=15&month=11&year=2022&search=day" class="ajax-load-link">15</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-2" id="day2022_11_16" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=16&month=11&year=2022&search=day" class="ajax-load-link">16</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-3" id="day2022_11_17">
                            <span>17</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-4" id="day2022_11_18" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=18&month=11&year=2022&search=day" class="ajax-load-link">18</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-5" id="day2022_11_19">
                            <span>19</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-6" id="day2022_11_20">
                            <span>20</span>
                        </td>
                                                </tr>
                                <tr class="calendar-dayrow">
                                                                                                                       <td class="thismonth viewrange outperiodday " headers="heading-0" id="day2022_11_21">
                            <span>21</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-1" id="day2022_11_22" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=22&month=11&year=2022&search=day" class="ajax-load-link">22</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-2" id="day2022_11_23" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=23&month=11&year=2022&search=day" class="ajax-load-link">23</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-3" id="day2022_11_24" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=24&month=11&year=2022&search=day" class="ajax-load-link">24</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-4" id="day2022_11_25">
                            <span>25</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-5" id="day2022_11_26">
                            <span>26</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday " headers="heading-6" id="day2022_11_27">
                            <span>27</span>
                        </td>
                                                </tr>
                                <tr class="calendar-dayrow">
                                                                                                                       <td class="thismonth viewrange outperiodday " headers="heading-0" id="day2022_11_28">
                            <span>28</span>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-1" id="day2022_11_29" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=29&month=11&year=2022&search=day" class="ajax-load-link">29</a>
                        </td>
                                                                                                                           <td class="thismonth viewrange outperiodday  hasEvents NotInFilter" headers="heading-2" id="day2022_11_30" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=30&month=11&year=2022&search=day" class="ajax-load-link">30</a>
                        </td>
                                                                                                                           <td class="fillday outperiodday  hasEvents NotInFilter" headers="heading-3" id="day2022_12_01" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=01&month=12&year=2022&search=day" class="ajax-load-link">01</a>
                        </td>
                                                                                                                           <td class="fillday outperiodday  hasEvents NotInFilter" headers="heading-4" id="day2022_12_02" style="background-color: #009df5; color:#fff;">
                            <a href="/display/events/?day=02&month=12&year=2022&search=day" class="ajax-load-link">02</a>
                        </td>
                                                                                                                           <td class="fillday outperiodday " headers="heading-5" id="day2022_12_03">
                            <span>03</span>
                        </td>
                                                                                                                           <td class="fillday outperiodday " headers="heading-6" id="day2022_12_04">
                            <span>04</span>
                        </td>
                                                </tr>
                </tbody>
    </table>
</div>










<!-- Events Calendar v2 by TERMINALFOUR -->
<!-- T4\Calendar :: Version: 2.4 -->
<div class="view-switchers align-centre ajax-load-area content-block" id="view_switchers" data-ajaxloadalso='["calendar_events", "view_period_switchers", "calendar_box","past_events","searchoptions","hidden_form_categories","hidden_form_generic","calendar_page"]'>
		    <a href="/display/events/?day=13&month=11&year=2022&search=day" class=" ajax-load-link">
        	Day
        	</a>
        |
    		<span>
	    	Week
    		</span>
	    |
        <a href="/display/events/?month=11&year=2022&search=month" class=" ajax-load-link">
        	Month
        	</a>
        |
        <a href="/display/events/?year=2022&search=year" class=" ajax-load-link">
        	Year
        	</a>
        |
        <a href="/display/events/?search=all" class=" ajax-load-link">
        	All
        	</a>
    </div>








<!-- Events Calendar v2 by TERMINALFOUR -->
<!-- T4\Calendar :: Version: 2.4 -->
<div id="searchoptions" class="calendar-cats content-block">
    <div
    id="searchoptions-generic"
    class="ajax-load-area search-filter"
    data-ajaxloadalso='["calendar_events", "calendar_box", "view_period_switchers", "view-switchers","calendar_page","jumpto_hidden_form","hidden_form_categories","past_events","hidden_form_dates","searchoptions-filters"]'
  >
    <form method="get" action="/display/events/">
      <div id="search_field">
        <label
          for="keywords"
          style="
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 16px;
            line-height: 24px;
          "
          >Search:</label
        >
        <input type="text" size="25" maxlength="80"  name="keywords" id="keywords"
        placeholder="Search for events"/>
      </div>

            <div id="hidden_form_generic">
                <input type="hidden" name="day" value="13" />
                <input type="hidden" name="month" value="11" />
                <input type="hidden" name="year" value="2022" />
                <input type="hidden" name="search" value="week" />
                <input type="hidden" name="past" value="1" />
                <input type="hidden" name="date-from" value="" />
                <input type="hidden" name="date-to" value="" />
              </div>

      <input
        type="submit"
        class="button calendar-button small"
        value="Search"
        name="submit"
        style="background-color: #009df5; font-size: 14px; width: fit-content;"
      />
    </form>
  </div>


<!-- Events Calendar v2 by TERMINALFOUR -->
<!-- T4\Calendar :: Version: 2.4 -->
<div id="searchoptions-categories" class="ajax-load-area" data-ajaxloadalso='["calendar_events", "calendar_box", "view_period_switchers", "view-switchers","calendar_page","jumpto_hidden_form","past_events","hidden_form_generic","hidden_form_dates","searchoptions-filters"]'>
    <form method="get" action="/display/events/" class="panel event-search-widget">
        <fieldset style="border: none; padding: 0;">
            <legend style="margin-bottom: 0.5rem;">Show categories:</legend>
                        <div id="hidden_form_categories">
                <input type="hidden"
                                                  value="week"
                                                  name="search" id="search_search"/>
                  <input type="hidden"
                                                  value="13"
                                                  name="day" id="search_day"/>
                  <input type="hidden"
                                                  value="11"
                                                  name="month" id="search_month"/>
                  <input type="hidden"
                                                  value="2022"
                                                  name="year" id="search_year"/>
                  <input type="hidden"
                                                  name="keywords" id="keywords"/>
                  <input type="hidden"
                                                  value="1"
                                                  name="past" id="past"/>
            </div>
                                                                <div class="category">                      
                        <label for="category_4d9a8d9067a945eda6cf153c069dce8f">
        				  <input  type="checkbox" name="categories[]" id="category_4d9a8d9067a945eda6cf153c069dce8f" value="Alumni" data-category="alumni" />
                            Alumni
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_577b27c4f994a4909f1e411d0ecc7463">
        				  <input  type="checkbox" name="categories[]" id="category_577b27c4f994a4909f1e411d0ecc7463" value="Arts and culture" data-category="arts and culture" />
                            Arts and culture
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_c8d647bf6cc7ca988e6ea5463eed09f1">
        				  <input  type="checkbox" name="categories[]" id="category_c8d647bf6cc7ca988e6ea5463eed09f1" value="Centenary Events" data-category="centenary events" />
                            Centenary Events
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_bb810f8c4a4afd11aed2b80b123b3336">
        				  <input  type="checkbox" name="categories[]" id="category_bb810f8c4a4afd11aed2b80b123b3336" value="Lectures, workshops and conferences" data-category="lectures, workshops and conferences" />
                            Lectures, workshops and conferences
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_8db08c68fc9846ee6c9da89407ad1e2a">
        				  <input  type="checkbox" name="categories[]" id="category_8db08c68fc9846ee6c9da89407ad1e2a" value="Online Conference" data-category="online conference" />
                            Online Conference
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_f7fb1621622427a6235fb5464ee34a6d">
        				  <input  type="checkbox" name="categories[]" id="category_f7fb1621622427a6235fb5464ee34a6d" value="Online and In-Person" data-category="online and in-person" />
                            Online and In-Person
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_263869517bef8b77085ee9c6f7fd04d9">
        				  <input  type="checkbox" name="categories[]" id="category_263869517bef8b77085ee9c6f7fd04d9" value="Special events and open days" data-category="special events and open days" />
                            Special events and open days
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_96faa3e6c45bb5a07bcc0bcd3be37654">
        				  <input  type="checkbox" name="categories[]" id="category_96faa3e6c45bb5a07bcc0bcd3be37654" value="Sport" data-category="sport" />
                            Sport
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_aba064f896dc3eb1653c3b68b9548ef1">
        				  <input  type="checkbox" name="categories[]" id="category_aba064f896dc3eb1653c3b68b9548ef1" value="Students" data-category="students" />
                            Students
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_0d015d96f63a8c12d96b8399482b593f">
        				  <input  type="checkbox" name="categories[]" id="category_0d015d96f63a8c12d96b8399482b593f" value="Uncategorized" data-category="uncategorized" />
                            Uncategorized
                        </label>
              		</div>
                                    <div class="category">                      
                        <label for="category_50dd9fb6d93c81e15cec36ffc49cd0f8">
        				  <input  type="checkbox" name="categories[]" id="category_50dd9fb6d93c81e15cec36ffc49cd0f8" value="Webinar" data-category="webinar" />
                            Webinar
                        </label>
              		</div>
                            
            <input type="submit" class="button calendar-button small" value="Show Categories" name="submit" style="background-color: #009df5; font-size: 14px; width: fit-content;" />

            <noscript>
              <!--<input type="submit" class="button calendar-button small" value="Submit" name="submit">-->
              <label for="reset-cal" class="sr-only">Clear</label>
			  <input type="reset" id="reset-cal" class="button" value="Clear">

			  <input type="submit" class="button" value="Search">
            </noscript>
        </fieldset>
    </form>
</div>
</div>


















    </div>
  </aside>
</section>

<!--** Start footer **-->
<div class="bg-wits-blue">
    <footer class="content-row footer">
        <div class="content-block">
            <section class="footer-soc-media-follow contact address content-row">
                <article class="content-block left">
  <span class="footer-title">Contact Us</span>
  <p><a href="/about-wits/contact-us/">General enquiries</a></p>
<p>Tel: +27 (0)11 717 1000</p>
<p><a href="/study-at-wits/">Admission enquiries</a></p>
<p>Tel: +27 (0)11 717 1888</p>
</article><article class="content-block left">
  <span class="footer-title">Find Us</span>
  <p>1 Jan Smuts Avenue,</p>
<p>Braamfontein 2000,</p>
<p>Johannesburg,</p>
<p>South Africa</p>
</article>
                <article class="content-block left">
          <span class="footer-title">Quicklinks</span>
         <p><a href="/vacancies/" target="_blank">Vacancies</a></p><p><a href="/students/academic-matters/term-dates/">Term dates</a></p><p><a href="/about-wits/tenders/">Tenders</a></p><p><a href="http://shop.wits.ac.za/" target="_blank">Wits Shop</a></p>
        </article>
                <article class="content-block left">
  <span class="footer-title">Connect with us</span>
  <ul class="soc-media-icons">
      <li><a href="http://www.facebook.com/witsuniversity" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
      <li><a href="https://www.instagram.com/wits__university/" target="_blank"><i class="fa fa-instagram"></i></a></li>
      <li><a href="http://twitter.com/witsuniversity" target="_blank"><i class="fa fa-twitter-square"></i></a></li>
      
      <li><a href="https://www.youtube.com/user/WitsWebmaster" target="_blank"><i class="fa fa-youtube-square"></i></a></li>
      <li><a href="http://www.linkedin.com/company/university-of-the-witwatersrand" target="_blank"><i class="fa fa-linkedin-square"></i></a></li>
      
      
    </ul>
  <p><a class="button" href="/givingtowits/">Give to Wits</a></p>
</article>
            </section>

            <!-- Footer legal -->
            <section class="content-row footer-legal ">
                <article class="content-block">
                    <section class="content-row">
  <article class="textual-article content-block">
  <span id="d.en.1699564"></span>
  
  
  
  <p>Copyright &copy; 2020-2022 - University of the Witwatersrand, Johannesburg.</p>
<p class="footer-links"><a href="/site-assets/small-footer/terms-and-conditions-of-use/">Terms and Conditions of Use</a>&nbsp;<a href="/site-assets/small-footer/popia-and-paia/">POPIA&nbsp;and PAIA</a>&nbsp;<a href="/site-assets/small-footer/ispa/">ISPA</a>&nbsp;<a href="/site-assets/small-footer/browser-support/">Browser Support</a></p>
</article>
</section>
                </article>
            </section>
            <!-- End Footer legal -->
        </div>
    </footer>
</div>
<!-- End footer -->

<section class="modal">
    <div class="content-row">
        <button class="close">Close</button>
        <div class="modal-content"></div>
    </div>
</section>
    <a class="exit-off-canvas"></a>
    </main>
    <!--** End .inner-wrap - Main **-->
  </div>

	

  <!--** End .outer-wrap contains everything **-->
  <script src="/media/wits-university-style-assets/javascript/jquery.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/foundation.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/slick.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/t4-custom.js"></script>
  <script src="/media/wits-university-style-assets/javascript/jquery.matchHeight-min.js"></script> <!-- matchHeight -->
  <script src="/media/wits-university-style-assets/javascript/updates.js"></script> <!-- updates -->
	<script>
    function() {
      $('#searchoptions :input').not(':button, :submit, :reset, :hidden, :checkbox, :radio').val('');
      $(':checkbox, :radio').prop('checked', false);
      return false;
    }
   
  </script>

	<script type="text/javascript" src="/media/wits-university/t4-dev---events-calendar/php-events-calendar.js"></script>
  <script>
    $(document).ready(function(){
      var startDate = $('.event-details .startDate').text();
      var endDate = $('.event-details .endDate').text();
      if (startDate == endDate) {
        $('.endDate').remove();
        $('.dateSeperator').remove();
      }
    });
  </script>
</body>
</html>
<script id="f5_cspm">(function(){var f5_cspm={f5_p:'AHILMDOAELEMJENECCHONFPLFPAFEIANPKMFNPAHLFHLLIIKOFDNDCNBNMCBENCNOEJBMJNAAAIOOKMFKLCACIGHAAKOALECBDDGCHMCBNMHGOGPDMLMDGMIIEDHDFJA',setCharAt:function(str,index,chr){if(index>str.length-1)return str;return str.substr(0,index)+chr+str.substr(index+1);},get_byte:function(str,i){var s=(i/16)|0;i=(i&15);s=s*32;return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);},set_byte:function(str,i,b){var s=(i/16)|0;i=(i&15);s=s*32;str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));return str;},set_latency:function(str,latency){latency=latency&0xffff;str=f5_cspm.set_byte(str,40,(latency>>8));str=f5_cspm.set_byte(str,41,(latency&0xff));str=f5_cspm.set_byte(str,35,2);return str;},wait_perf_data:function(){try{var wp=window.performance.timing;if(wp.loadEventEnd>0){var res=wp.loadEventEnd-wp.navigationStart;if(res<60001){var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);window.document.cookie='f5avr1169112156aaaaaaaaaaaaaaaa_cspm_='+encodeURIComponent(cookie_val)+';path=/';}
return;}}
catch(err){return;}
setTimeout(f5_cspm.wait_perf_data,100);return;},go:function(){var chunk=window.document.cookie.split(/\s*;\s*/);for(var i=0;i<chunk.length;++i){var pair=chunk[i].split(/\s*=\s*/);if(pair[0]=='f5_cspm'&&pair[1]=='1234')
{var d=new Date();d.setTime(d.getTime()-1000);window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;';setTimeout(f5_cspm.wait_perf_data,100);}}}}
f5_cspm.go();}());</script>