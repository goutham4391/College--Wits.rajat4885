
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="author" content="The University of the Witwatersrand, Johannesburg">
  <meta name="generator" content="TERMINALFOUR">

  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-10871141-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-10871141-1');
</script>

  <script type="text/javascript">
            var vsid = "sa51850";
            (function () {
                var vsjs = document.createElement('script');
                vsjs.type = 'text/javascript';
                vsjs.async = true;
                vsjs.setAttribute('defer', 'defer');
                vsjs.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'www.virtualspirits.com/vsa/chat-' + vsid + 
                '.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(vsjs, s);
            })();
        </script>
  <meta name="description" content="">
  
  
  <title>Upcoming Events - Wits University</title>
  
  <link rel="shortcut icon" href="/media/wits-university-style-assets/images/favicon.ico" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/style-local.css" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/slick.css" />
  <link rel="stylesheet" href="/media/wits-university-style-assets/css/style-updates.css" />
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400italic,400,700,600" type="text/css">

  <style>
    td.hasEvents:hover {
    	background-color: #007cc2 !important;
    	text-decoration: underline !important;
    }
  </style>

 	<!-- T4 updated style -->
  <link rel="stylesheet" type="text/css" media="" href="/media/wits-university-style-assets/css/style-updates-renamed.css" />
  <!-- Redesign css -->
  <link rel="stylesheet" type="text/css" media="" href="/media/wits-university-style-assets/css/redesign.css" />

  <script src="/media/wits-university-style-assets/javascript/modernizr.js"></script>
</head>
<body class="gen-content events">
  <div class="emergencynotice" aria-live="assertive"></div>
  <!--** End .outer-wrap contains everything **-->
  <div class="off-canvas-wrap" data-offcanvas>
    <!--** Main body .inner-wrap wraps around all content **-->
    <main class="inner-wrap">
			<!--** Desktop header **-->
      <header aria-hidden="true" class="page-head-desktop">
        <section class="content-row">
          <!--** Logo **-->
          <div class="logo-desktop">
              <a href="/" title="University of the Witwatersrand"><img src="/media/wits-university-style-assets/images/Wits_Centenary_Logo_Large.svg" alt="The University of the Witwatersrand Logo" title="The University of the Witwatersrand Logo" class="" style="   " ></a>
          </div>
          <!--** End Logo **-->
          <!--** Meta-nav and Search **-->
          <div class="meta-nav-and-search ">
            <!--** Meta-nav **-->
            <div class="meta-nav">
              <ul class="inline-list">
              <li><a href="/about-wits/">About</a></li><li><a href="/staff/">Staff</a></li><li><a href="/alumni/">Alumni</a></li><li><a href="/givingtowits/">Give</a></li><li><a href="/library/">Library</a></li><li><a href="/news/">News and Events</a></li><li><a href="http://wits100.wits.ac.za" target="_blank">Wits100</a></li>
              </ul>
            </div>
            <!--** End Meta-nav **-->
            <!--** Desktop main nav **-->
            <div class="navigation-search">
              <a href="/">
              <button class="homepage-link button" title="Link to homepage"
                ><i class="fa fa-home"></i><span class="sr-only">Homepage</span>
              </button>
              </a>
              <nav class="content-row main-nav">
                <div class="content-block">
                  <ul class="inline-list">
                    <li><a href="/study-at-wits/">Study at Wits</a></li><li><a href="/students/">Students</a></li><li><a href="/faculties-and-schools/">Faculties and Schools</a></li><li><a href="/teaching-and-learning/">Teaching and Learning</a></li><li><a href="/research/">Research</a></li><li><a href="/news/">News</a></li>
                  </ul>    
                </div>
              </nav>
              <button class="search-display button" title="Search bar revelar"
                ><i class="fa fa-search"></i><span class="sr-only">Search</span>
              </button>
            </div>
            
            <!--** Search **-->
            <div class="search search-hidden">
              <form id="site-search" action="/search-results/">
                                    <label class="site-search-label at-hidden" for="site-search-text-d">Search the site</label>
                                    <div class="content-row search-row">
                                        <div class="site-search-text content-block">
                                            <input type="text" name="q" id="site-search-text-d" placeholder="Search">
                                        </div>
                                        <div class="search-now content-block">
                                            <span class="postfix">
                                                <button type="submit" class="search-now button" title="Search now">
                                                    <i class="fa fa-search"></i>
                                                    <span>Search</span>
                                                </button>                                                    
                                            </span>
                                        </div>
                                    </div>
                                </form>
            </div>
            <!--** End search **-->
          </div>
          <!--** End Meta-nav and Search **-->
        </section>       
      </header>
      <!--** End desktop header **-->
      <!--** Mobile Header **-->
      <header class="mobile-header">
        <!--** Mobile Top panel **-->
        <nav class="tab-bar">
            <section class="left-small">
              <a class="left-off-canvas-toggle menu-icon" href="#off-canvas">
                <span></span>
                Menu
              </a>
            </section>
            <section class="right-small">
              <a class="search-toggle" href="#">Search <i class="fa fa-search"></i></a>
            </section>
        </nav>
        <!--** Mobile Top panel **-->
        <!--** Mob site search **-->
        <section class="mobile-site-search content-row">
          <div class="content-block">
            <form id="site-search" action="/search-results/">
                                    <label class="site-search-label at-hidden" for="site-search-text-d">Search the site</label>
                                    <div class="content-row search-row">
                                        <div class="site-search-text content-block">
                                            <input type="text" name="q" id="site-search-text-d" placeholder="Search">
                                        </div>
                                        <div class="search-now content-block">
                                            <span class="postfix">
                                                <button type="submit" class="search-now button" title="Search now">
                                                    <i class="fa fa-search"></i>
                                                    <span>Search</span>
                                                </button>                                                    
                                            </span>
                                        </div>
                                    </div>
                                </form>
          </div>
        </section>
        <!--** End mob site search **-->           
        <!--** Mobile logo **-->
        <section class="logos logo-mobile">
          <div class="wits-logo logo"><a href="/" title="University of the Witwatersrand"><img src="/media/wits-university-style-assets/images/Wits_Centenary_Logo_Large.svg" alt="The University of the Witwatersrand Logo" title="The University of the Witwatersrand Logo" class="" style="   " ></a></div>
        </section>
        <!--** End logo mobile **-->

        <!--** Off canvas menu **-->
        <aside id="off-canvas" class="left-off-canvas-menu">
          <p class="at-hidden"><a href="#start-content">Skip navigation and go to page content</a></p>
          <nav>
            <!-- Main nav -->
            <ul class="off-canvas-list">
              <li><label>Sections</label></li>
              <li><a href="/study-at-wits/">Study at Wits</a></li><li><a href="/students/">Students</a></li><li><a href="/faculties-and-schools/">Faculties and Schools</a></li><li><a href="/teaching-and-learning/">Teaching and Learning</a></li><li><a href="/research/">Research</a></li><li><a href="/news/">News</a></li>
            </ul>
            <!-- End main nav -->
            <!-- Meta nav -->
             <ul class="off-canvas-meta-nav">
              <li><a href="/about-wits/">About</a></li><li><a href="/staff/">Staff</a></li><li><a href="/alumni/">Alumni</a></li><li><a href="/givingtowits/">Give</a></li><li><a href="/library/">Library</a></li><li><a href="/news/">News and Events</a></li><li><a href="http://wits100.wits.ac.za" target="_blank">Wits100</a></li>
            </ul>
            <!-- End Meta nav -->
          </nav>
        </aside>
        <!--** End off canvas menu **-->
      </header>
      <!--** End Mobile header **-->
      <!--** Ribbon message for users on IE<10 **-->
      <div style="display: none;" class="content-row ie-ribbon"></div> 
      <!--** Start content **-->
      <a id="start-content" name="start-content" class="at-hidden">Start main page content</a>
      <section class="content-row no-padding-bottom">
        <nav class="content-block">
          <ul class="breadcrumbs"><li><a href="/">Home</a><i class="fa fa-angle-right"></i></li><li><a href="/alumni/">Alumni</a><i class="fa fa-angle-right"></i></li><li><a href="/alumni/alumni-events/">Alumni Events</a><i class="fa fa-angle-right"></i></li><li>Upcoming Events</li></ul>
        </nav>
      </section>

      <section class="gen-main-content-row content-row">
        <section class="gen-main-body content-block" style="padding-left: 2rem;">
          <h1>Events</h1>
<div class="grid-container">
  <div class="event-fulltext" data-contentid="2871470">
<h1>International Reunion, Brisbane, Australia</h1>
<table class="event-details">
  <tbody>
    <tr>
      <td>When:</td>
      <td>        
        <!--You need to load the T4EventsCalendar Class-->    Sunday, 13 November 2022

                 
</td>
    </tr>  
    <tr>
      <td>Where:</td>
      <td><br>Roma Room, Hotel Grand Chancellor Brisbane, 23 Leichhardt Street (Cnr Wickham Terrace), Brisbane, QLD 4000</td>
    </tr>  
    <tr>
      <td>Start time:</td><td>18:00</td>
    </tr> 
    <tr>
      <td>Enquiries:</td><td><p>events.alumni@wits.ac.za</p></td>
    </tr> 
    <tr>
      <td>RSVP:</td><td><a href="mailto:rsvp@example.za"><p><a href="https://alumni.custhelp.com/ci/documents/detail/5/290/12/db02ca5da8fe6251fd2f1b437050e6e66b7ef070/13/MTY2NDE4ODYyOQ==" target="_blank" rel="noopener">here</a></p></a></td>
    </tr> 
    
  </tbody>
</table>


<p class="intro">Celebrate the University&rsquo;s centenary with us</p>
<p><span>We are proud of your achievements so this would be a wonderful opportunity to acknowledge your success, reminisce, update you on Wits news, answer questions, and meet fellow Witsies.&nbsp;We look forward to seeing you!&nbsp;Cocktails and refreshments will be served after the formal proceedings.</span></p>
  
  <a class="ical-btn" href="/alumni/alumni-events/upcoming-events/event-2871470.ics"><img class="ical-img" src="/media/wits-university/campus-life/images/Calendar-Date-04.png" alt="calendar icon" >Add event to calendar</a>
  <br>
</div>
</div>
<!--<a href="/alumni/alumni-events/upcoming-events/international-reunion-brisbane-australia-1.php">International Reunion, Brisbane, Australia</a>-->
              





<!--
<div class="grid-container">
  <div class="event-fulltext" data-contentid="2871470">
<h1>International Reunion, Brisbane, Australia</h1>
<table class="event-details">
  <tbody>
    <tr>
      <td>When:</td>
      <td>Sunday, 13 November 2022</td>
    </tr>  
    <tr>
      <td>Where:</td>
      <td><br>Roma Room, Hotel Grand Chancellor Brisbane, 23 Leichhardt Street (Cnr Wickham Terrace), Brisbane, QLD 4000</td>
    </tr>  
    <tr>
      <td>Start time:</td><td>18:00</td>
    </tr> 
    <tr>
      <td>Enquiries:</td><td><p>events.alumni@wits.ac.za</p></td>
    </tr> 
    <tr>
      <td>RSVP:</td><td><a href="mailto:rsvp@example.za"><p><a href="https://alumni.custhelp.com/ci/documents/detail/5/290/12/db02ca5da8fe6251fd2f1b437050e6e66b7ef070/13/MTY2NDE4ODYyOQ==" target="_blank" rel="noopener">here</a></p></a></td>
    </tr> 
    
  </tbody>
</table>


<p class="intro">Celebrate the University&rsquo;s centenary with us</p>
<p><span>We are proud of your achievements so this would be a wonderful opportunity to acknowledge your success, reminisce, update you on Wits news, answer questions, and meet fellow Witsies.&nbsp;We look forward to seeing you!&nbsp;Cocktails and refreshments will be served after the formal proceedings.</span></p>
  
  <a class="ical-btn" href="/alumni/alumni-events/upcoming-events/event-2871470.ics"><img class="ical-img" src="/media/wits-university/campus-life/images/Calendar-Date-04.png" alt="calendar icon" >Add event to calendar</a>
  <br>
</div>
</div>
<!--<a href="/alumni/alumni-events/upcoming-events/international-reunion-brisbane-australia-1.php">International Reunion, Brisbane, Australia</a>-->  </section>

  <aside class="gen-content-lh-sidebar content-block">
    <div class="content-row">
		  
    </div>
  </aside>
</section>

<!--** Start footer **-->
<div class="bg-wits-blue">
    <footer class="content-row footer">
        <div class="content-block">
            <section class="footer-soc-media-follow contact address content-row">
                <article class="content-block left">
  <span class="footer-title">Contact Us</span>
  <p><a href="/about-wits/contact-us/">General enquiries</a></p>
<p>Tel: +27 (0)11 717 1000</p>
<p><a href="/study-at-wits/">Admission enquiries</a></p>
<p>Tel: +27 (0)11 717 1888</p>
</article><article class="content-block left">
  <span class="footer-title">Find Us</span>
  <p>1 Jan Smuts Avenue,</p>
<p>Braamfontein 2000,</p>
<p>Johannesburg,</p>
<p>South Africa</p>
</article>
                <article class="content-block left">
          <span class="footer-title">Quicklinks</span>
         <p><a href="/vacancies/" target="_blank">Vacancies</a></p><p><a href="/students/academic-matters/term-dates/">Term dates</a></p><p><a href="/about-wits/tenders/">Tenders</a></p><p><a href="http://shop.wits.ac.za/" target="_blank">Wits Shop</a></p>
        </article>
                <article class="content-block left">
  <span class="footer-title">Connect with us</span>
  <ul class="soc-media-icons">
      <li><a href="http://www.facebook.com/witsuniversity" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
      <li><a href="https://www.instagram.com/wits__university/" target="_blank"><i class="fa fa-instagram"></i></a></li>
      <li><a href="http://twitter.com/witsuniversity" target="_blank"><i class="fa fa-twitter-square"></i></a></li>
      
      <li><a href="https://www.youtube.com/user/WitsWebmaster" target="_blank"><i class="fa fa-youtube-square"></i></a></li>
      <li><a href="http://www.linkedin.com/company/university-of-the-witwatersrand" target="_blank"><i class="fa fa-linkedin-square"></i></a></li>
      
      
    </ul>
  <p><a class="button" href="/givingtowits/">Give to Wits</a></p>
</article>
            </section>

            <!-- Footer legal -->
            <section class="content-row footer-legal ">
                <article class="content-block">
                    <section class="content-row">
  <article class="textual-article content-block">
  <span id="d.en.1699564"></span>
  
  
  
  <p>Copyright &copy; 2020-2022 - University of the Witwatersrand, Johannesburg.</p>
<p class="footer-links"><a href="/site-assets/small-footer/terms-and-conditions-of-use/">Terms and Conditions of Use</a>&nbsp;<a href="/site-assets/small-footer/popia-and-paia/">POPIA&nbsp;and PAIA</a>&nbsp;<a href="/site-assets/small-footer/ispa/">ISPA</a>&nbsp;<a href="/site-assets/small-footer/browser-support/">Browser Support</a></p>
</article>
</section>
                </article>
            </section>
            <!-- End Footer legal -->
        </div>
    </footer>
</div>
<!-- End footer -->

<section class="modal">
    <div class="content-row">
        <button class="close">Close</button>
        <div class="modal-content"></div>
    </div>
</section>
    <a class="exit-off-canvas"></a>
    </main>
    <!--** End .inner-wrap - Main **-->
  </div>

	

  <!--** End .outer-wrap contains everything **-->
  <script src="/media/wits-university-style-assets/javascript/jquery.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/foundation.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/slick.min.js"></script>
  <script src="/media/wits-university-style-assets/javascript/t4-custom.js"></script>
  <script src="/media/wits-university-style-assets/javascript/jquery.matchHeight-min.js"></script> <!-- matchHeight -->
  <script src="/media/wits-university-style-assets/javascript/updates.js"></script> <!-- updates -->
	<script>
    function() {
      $('#searchoptions :input').not(':button, :submit, :reset, :hidden, :checkbox, :radio').val('');
      $(':checkbox, :radio').prop('checked', false);
      return false;
    }
   
  </script>

	<script type="text/javascript" src="/media/wits-university/t4-dev---events-calendar/php-events-calendar.js"></script>
  <script>
    $(document).ready(function(){
      var startDate = $('.event-details .startDate').text();
      var endDate = $('.event-details .endDate').text();
      if (startDate == endDate) {
        $('.endDate').remove();
        $('.dateSeperator').remove();
      }
    });
  </script>
</body>
</html>
<script id="f5_cspm">(function(){var f5_cspm={f5_p:'IFKINHFFBEBLMLNHFEMKMBDPKLPLMDMEMDMMGINILOGCEAMGHIMCDOHCFDNFNFBOIBABNOFCAADMELEALKKADBJAAAKNNBAMJAOBDKEIFCMJCJLHFLKPEFKIDNMACOCI',setCharAt:function(str,index,chr){if(index>str.length-1)return str;return str.substr(0,index)+chr+str.substr(index+1);},get_byte:function(str,i){var s=(i/16)|0;i=(i&15);s=s*32;return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);},set_byte:function(str,i,b){var s=(i/16)|0;i=(i&15);s=s*32;str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));return str;},set_latency:function(str,latency){latency=latency&0xffff;str=f5_cspm.set_byte(str,40,(latency>>8));str=f5_cspm.set_byte(str,41,(latency&0xff));str=f5_cspm.set_byte(str,35,2);return str;},wait_perf_data:function(){try{var wp=window.performance.timing;if(wp.loadEventEnd>0){var res=wp.loadEventEnd-wp.navigationStart;if(res<60001){var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);window.document.cookie='f5avr1169112156aaaaaaaaaaaaaaaa_cspm_='+encodeURIComponent(cookie_val)+';path=/';}
return;}}
catch(err){return;}
setTimeout(f5_cspm.wait_perf_data,100);return;},go:function(){var chunk=window.document.cookie.split(/\s*;\s*/);for(var i=0;i<chunk.length;++i){var pair=chunk[i].split(/\s*=\s*/);if(pair[0]=='f5_cspm'&&pair[1]=='1234')
{var d=new Date();d.setTime(d.getTime()-1000);window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;';setTimeout(f5_cspm.wait_perf_data,100);}}}}
f5_cspm.go();}());</script>